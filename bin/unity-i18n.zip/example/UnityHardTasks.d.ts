import { LocalizeTask } from "../LocalizeOption.js";
declare const UnityHardTasks: {
    searchTasks: LocalizeTask[];
    replaceTasks: LocalizeTask[];
    replacer: {
        $workspace: string;
    };
};
export default UnityHardTasks;
