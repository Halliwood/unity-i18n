import { LocalizeTask } from "../LocalizeOption.js";
declare let UnitySoftTasks: {
    searchTasks: LocalizeTask[];
    replaceTasks: LocalizeTask[];
    replacer: {
        $workspace: string;
    };
};
export default UnitySoftTasks;
