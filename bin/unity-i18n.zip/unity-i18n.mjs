#!/usr/bin/env node

import './index.js';