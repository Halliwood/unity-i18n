export declare enum Ei18nErrorCode {
    Success = 0,
    Failed = 1,
    NoLocal = 1000,
    ConcatStrings = 1001,
    SyntaxError = 1002,
    FormatError = 1003
}
