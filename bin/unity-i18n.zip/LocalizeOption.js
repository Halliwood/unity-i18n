export var LocalizeMode;
(function (LocalizeMode) {
    LocalizeMode[LocalizeMode["Search"] = 0] = "Search";
    LocalizeMode[LocalizeMode["Replace"] = 1] = "Replace";
})(LocalizeMode || (LocalizeMode = {}));
//# sourceMappingURL=LocalizeOption.js.map